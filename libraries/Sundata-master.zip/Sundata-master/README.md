Sundata
=======

Arduino Library for calculating Sun's Elevation, Azimuth, Sunrise Time and Sunset Time.
